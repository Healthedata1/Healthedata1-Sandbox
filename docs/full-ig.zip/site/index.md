#### SUSHI Sandbox

testbed for ideas....

#### FOO

using http:

[US Core](http://hl7.org/fhir/us/core/STU4/index.html)

[FHIR](http://hl7.org/fhir/)



using https:

[US Core](https://hl7.org/fhir/us/core/STU4/index.html)

[FHIR](https://hl7.org/fhir/)

using path variable

[FHIR]({{site.data.fhir.path}})

#### in list...:

using http:

- [US Core](http://hl7.org/fhir/us/core/STU4/index.html)
- [FHIR](http://hl7.org/fhir/)

using https:

- [US Core](https://hl7.org/fhir/us/core/STU4/index.html)
- [FHIR](https://hl7.org/fhir/)

#### in table...:

using http:

|link|
|---|
|[US Core](http://hl7.org/fhir/us/core/STU4/index.html)|
|[FHIR](http://hl7.org/fhir/)|
{:.grid}

using https:

|link|
|---|
|[US Core](https://hl7.org/fhir/us/core/STU4/index.html)|
|[FHIR](https://hl7.org/fhir/)|
{:.grid}
